//
//  ViewController.swift
//  GasAlarm
//
//  Created by Владислав Семенец on 03.06.2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

